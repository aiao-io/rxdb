module.exports = 'AIAO_TERMINAL_DEPENDENCY_OK';
